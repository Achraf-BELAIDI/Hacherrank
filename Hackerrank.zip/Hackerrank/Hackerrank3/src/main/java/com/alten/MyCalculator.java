package com.alten;

class MyCalculator {

    public int power(int n, int p) {
        if (n == 0 && p == 0) {
            throw new IllegalArgumentException("0 élevé à la puissance 0 est indéfini.");
        }
        if (p < 0) {
            throw new IllegalArgumentException("L'exposant doit être un entier non négatif.");
        }
        return (int) Math.pow(n, p);
    }
}

package com.alten;

import java.util.Scanner;

public class Solution {
    public static final MyCalculator my_calculator = new MyCalculator();
    public static final Scanner in = new Scanner(System.in);

    public static void main(String[] args) {
        System.out.print("Veuillez entrer un nombre entier (n) : ");
        int n = in.nextInt();

        System.out.print("Veuillez entrer l'exposant entier (p) : ");
        int p = in.nextInt();

        try {
            System.out.println("Résultat : " + my_calculator.power(n, p));
        } catch (Exception e) {
            System.out.println("Erreur : " + e.getMessage());
        }
        in.close();
    }
}

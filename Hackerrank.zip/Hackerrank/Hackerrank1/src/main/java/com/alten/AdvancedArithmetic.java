package com.alten;

public interface AdvancedArithmetic {
    int divisorSum(int n);
}

package com.alten;

import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("Entrez un entier pour lequel vous voulez connaître les diviseurs et leur somme : ");
        int n = scanner.nextInt();

        MyCalculator myCalculator = new MyCalculator();

        System.out.println("I implemented: AdvancedArithmetic");

        System.out.println("Les diviseurs de " + n + " sont : " + myCalculator.getDivisors(n));

        int result = myCalculator.divisorSum(n);

        System.out.println("La somme des diviseurs de " + n + " est : " + result);

        scanner.close();
    }
}

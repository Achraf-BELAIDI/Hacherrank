package com.alten;

import java.util.Scanner;

public class Solution {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.println("================================");

        for (int i = 0; i < 3; i++) {
            System.out.print("Veuillez entrer une chaîne (exemple : texte) : ");
            String str = sc.next();

            System.out.print("Veuillez entrer un entier  : ");
            int num = sc.nextInt();

            System.out.printf("%-15s%03d\n", str, num);
        }

        System.out.println("================================");

        sc.close();
    }
}

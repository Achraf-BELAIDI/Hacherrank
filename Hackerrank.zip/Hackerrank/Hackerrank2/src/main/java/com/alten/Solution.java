package com.alten;

import java.util.Scanner;

public class Solution {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.print("Entrez une chaîne de caractères : ");
        String input = scanner.nextLine();

        String upperCaseInput = input.toUpperCase();

        System.out.println("La chaîne en majuscules est : " + upperCaseInput);

        scanner.close();
    }
}

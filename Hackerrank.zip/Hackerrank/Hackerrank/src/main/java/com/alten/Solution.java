package com.alten;

import java.security.MessageDigest;
import java.util.Scanner;

public class Solution {

    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        System.out.print("Entrez la chaîne à hacher avec SHA-256 : ");
        String input = sc.nextLine();

        try {

            MessageDigest md = MessageDigest.getInstance("SHA-256");

            byte[] hashBytes = md.digest(input.getBytes());

            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                hexString.append(String.format("%02x", b));
            }

            System.out.println("Hash SHA-256 : " + hexString.toString());
        } catch (Exception e) {
            e.printStackTrace();
        }

        sc.close();
    }
}
